from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Direction, Color
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait
from umath import sin, cos, atan2, sqrt, radians, degrees

#================= 1. CONFIGURAÇÕES GERAIS =================
VEL_VELOCIDADE = 1000
VEL_DESVIO = 1000
VEL_ACELERACAO = 1000
DIST_MARGEM = 140
DIST_RECUO = -5

# Ganhos PID
PID_GIRO = {"kp": 4.5, "ki": 0.08, "kd": 2.2, "limite_i": 5}
OBSTACULOS = [{"x": (-3000, -1000), "y": (300, 500)}]

#================= 2. HARDWARE E ESTADO =================
hub = PrimeHub()
motor_esq = Motor(Port.F, Direction.COUNTERCLOCKWISE)
motor_dir = Motor(Port.E)
motor_peq1 = Motor(Port.B)
motor_peq2 = Motor(Port.A)
sensor_cor = ColorSensor(Port.C)
drive = DriveBase(motor_esq, motor_dir, wheel_diameter=60, axle_track=110)

drive.settings(straight_speed=VEL_VELOCIDADE, straight_acceleration=VEL_ACELERACAO)

x_atual, y_atual = 0.0, 0.0
dist_anterior = 0.0
erro_anterior = 0
erro_inicial = 0
integral = 0

#================= 3. MOTORES DE CÁLCULO =================
def atualizar_odometria():
	global x_atual, y_atual, dist_anterior
	dist_total = drive.distance()
	delta_dist = dist_total - dist_anterior
	theta = radians(hub.imu.heading())
	x_atual += delta_dist * sin(theta)
	y_atual += delta_dist * cos(theta)
	dist_anterior = dist_total

def calcular_pid(erro):
	global erro_anterior, integral
	P = PID_GIRO["kp"] * erro
	integral += erro
	if abs(integral) > PID_GIRO["limite_i"]:
		integral = (integral / abs(integral)) * PID_GIRO["limite_i"]
	I = PID_GIRO["ki"] * integral
	D = PID_GIRO["kd"] * (erro - erro_anterior)
	erro_anterior = erro
	return P + I + D

#================= 4. NAVEGAÇÃO FLUIDA =================
def andar_ate(x_alvo, y_alvo, velocidade, detectar=True):
	global x_atual, y_atual, integral, erro_anterior, dist_anterior
	drive.reset()
	dist_anterior = 0
	integral = 0
	erro_anterior = 0

	while True:
		atualizar_odometria()
		dx, dy = x_alvo - x_atual, y_alvo - y_atual
		distancia_restante = sqrt(dx**2 + dy**2)

		if distancia_restante < 20:
			drive.stop()
			return "CHEGOU"

		angulo_alvo = degrees(atan2(dx, dy))
		angulo_atual = hub.imu.heading()
		erro_angulo = (angulo_alvo - angulo_atual + 180) % 360 - 180
		correcao = calcular_pid(erro_angulo)
		v_ajustada = velocidade if abs(erro_angulo) < 30 else velocidade * 0.4
		drive.drive(v_ajustada, correcao)
		wait(10)

		if detectar:
			for obs in OBSTACULOS:
				if (obs["x"][0] - 10 <= x_atual <= obs["x"][1] + 10 and
					obs["y"][0] - 10 <= y_atual <= obs["y"][1] + 10):
					drive.stop()
					return obs

def IR_PARA(x_final, y_final, velocidade, angulo_final=None, angulo_inicial=None):
	resultado = andar_ate(x_final, y_final, velocidade, detectar=True)

	if resultado != "CHEGOU":
		print("Obstáculo detectado! Contornando...")
		drive.straight(DIST_RECUO)
		atualizar_odometria()
		ponto_desvio_x = resultado["x"][1] + DIST_MARGEM
		ponto_desvio_y = y_atual
		andar_ate(ponto_desvio_x, ponto_desvio_y, VEL_DESVIO, detectar=False)
		andar_ate(ponto_desvio_x, resultado["y"][1] + DIST_MARGEM, VEL_DESVIO, detectar=False)
		return IR_PARA(x_final, y_final, velocidade, angulo_final, angulo_inicial)

	if angulo_inicial is not None:
		erro_inicial = (angulo_inicial - hub.imu.heading() + 180) % 360 - 180
		drive.turn(erro_inicial)

	if angulo_final is not None:
		erro_final = (angulo_final - hub.imu.heading() + 180) % 360 - 180
		drive.turn(erro_final)

	print("Destino atingido!")

def PA(x_novo, y_novo):
	global x_atual, y_atual, dist_anterior
	x_atual, y_atual = x_novo, y_novo
	drive.reset()
	dist_anterior = 0

def T(distancia_mm, velocidade=700):
	config_original = drive.settings()
	drive.settings(straight_speed=velocidade)
	drive.straight(-distancia_mm)
	drive.settings(straight_speed=config_original[0])
	atualizar_odometria()

def GMU(graus, velocidade):
	motor_peq1.run_angle(velocidade, graus)

def GMD(graus, velocidade):
	motor_peq2.run_angle(velocidade, graus)

def A(distancia_mm, velocidade):
	config_original = drive.settings()
	drive.settings(straight_speed=velocidade)
	drive.straight(distancia_mm)
	drive.settings(straight_speed=config_original[0])
	atualizar_odometria()

def V(graus_desejados):
	angulo_inicial = hub.imu.heading()
	angulo_alvo = angulo_inicial + graus_desejados
	erro_anterior = 0
	integral = 0
	kp = PID_GIRO["kp"]
	ki = PID_GIRO["ki"]
	kd = PID_GIRO["kd"]
	limite_i = PID_GIRO["limite_i"]

	while True:
		angulo_atual = hub.imu.heading()
		erro = (angulo_alvo - angulo_atual + 180) % 360 - 180

		if abs(erro) < 1.0:
			drive.stop()
			break

		P = kp * erro
		integral += erro

		if abs(integral) > limite_i:
			integral = (integral / abs(integral)) * limite_i

		I = ki * integral
		D = kd * (erro - erro_anterior)
		erro_anterior = erro
		velocidade_rotacao = P + I + D
		velocidade_rotacao = max(-400, min(400, velocidade_rotacao))
		drive.drive(0, velocidade_rotacao)
		wait(10)
		atualizar_odometria()

#================= 5. EXECUÇÃO =================
cor_lida = sensor_cor.color()

def saida_1():
	print("Aguardando detecção da cor...")
	hub.imu.reset_heading(0)
	drive.reset()
	IR_PARA(100, 100, 1000, 80, 90)

if cor_lida == Color.RED:
	saida_1()
elif cor_lida == Color.YELLOW:
	saida_2()
elif cor_lida == Color.ORANGE:
	saida_3()
elif cor_lida == Color.MAGENTA:
	saida_4()
elif cor_lida == Color.GREEN:
	saida_5()
elif cor_lida == Color.BLUE:
	saida_6()
elif cor_lida == Color.GRAY:
	saida_7()
